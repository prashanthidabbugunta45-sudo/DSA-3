# Lexicon Elite

REDESIGN LEXICON AS AN ULTRA-LUXURY, HIGH-END SOFTWARE PRODUCT.

THIS IS NOT A NORMAL STUDENT PROJECT UI.

I want the final application to look like a premium product from a world-class technology company — sophisticated, expensive, editorial, cinematic, restrained and exceptionally polished.

The FIRST IMPRESSION must be:

"Premium. Intelligent. Sophisticated. Custom-designed."

NOT:

"Student project."
"AI-generated dashboard."
"Generic SaaS template."
"Shadcn demo."
"Admin panel."

The DSA functionality must remain academically correct, but the visual presentation should be exceptionally luxurious.

==================================================
1. VISUAL ART DIRECTION — MOST IMPORTANT
==================================================

Design language:

LUXURY EDITORIAL TECHNOLOGY
+
PRIVATE RESEARCH LABORATORY
+
HIGH-END DIGITAL PRODUCT

Imagine the visual quality of:
- a luxury fashion house website
- a premium financial terminal
- an elite research laboratory
- a high-end typography studio
- an expensive architectural portfolio

But translated into a sophisticated computer-science product.

The application should feel designed by a professional product/design team.

DO NOT use generic UI blocks everywhere.

DO NOT make every section look like a rounded card.

DO NOT make everything centered.

Use composition, typography, whitespace, borders, hierarchy and asymmetry to create luxury.

==================================================
2. COLOR PALETTE
==================================================

PRIMARY DARK:

Almost-black charcoal:
#0C0C0B

SECONDARY DARK:

#151513

WARM IVORY:

#F4F0E7

PAPER:

#EDE8DC

CHAMPAGNE:

#C8A96B

PALE GOLD:

#D9C18B

MUTED TEXT:

#9B968B

WHITE:

#FAF8F2

The gold must be EXTREMELY restrained.

Gold should appear only on:
- key numbers
- tiny dividers
- selected states
- important algorithm highlights
- subtle borders
- premium accents

NEVER create a gold-gradient website.

==================================================
3. TYPOGRAPHY
==================================================

Typography is one of the most important parts of the luxury appearance.

Use an elegant high-contrast serif display typeface for:

LEXICON
hero headings
major section titles
large numbers

Use a refined modern sans-serif for:

navigation
body text
controls
tables
algorithm details

Create strong contrast between serif and sans-serif.

Use oversized typography.

Example:

LEXICON

should feel like a luxury wordmark rather than an ordinary application title.

Use:
- large tracking
- generous whitespace
- carefully controlled line height
- small uppercase labels
- editorial typography hierarchy

Avoid huge bold sans-serif headings everywhere.

==================================================
4. NAVIGATION
==================================================

Create an exceptionally refined navigation bar.

Dark charcoal background.

Left:

LEXICON

Small subtitle underneath:

SMART SPELL CHECKER

Center/right navigation:

CORRECT
DICTIONARY
ALGORITHM
EVALUATION
RESEARCH

Far right:

VIVA MODE

Navigation should be extremely minimal.

Thin 1px separators.

No giant pill-shaped navbar.

No hamburger-style SaaS dashboard appearance on desktop.

Add a tiny status indicator:

● LOCAL ENGINE

Meaning:
The correction engine runs locally.

Use very subtle champagne color.

==================================================
5. HERO — MAKE THIS STUNNING
==================================================

The hero must be the most visually impressive part of the application.

Full viewport.

Deep charcoal background.

Large editorial typography.

Small eyebrow:

DATA STRUCTURES & ALGORITHMS — 03

Then:

LEXICON

SMART SPELL CHECKER

Large serif statement:

"Precision begins
with the smallest edit."

Supporting text:

"A dictionary-driven correction engine that transforms imperfect queries into precise words using Levenshtein distance and Dynamic Programming."

Buttons:

OPEN CORRECTION ENGINE
VIEW THE ALGORITHM

Do not make normal rounded blue buttons.

Buttons should be refined:
- thin champagne border
- ivory text
- subtle hover fill
- generous spacing

==================================================
6. HERO ALGORITHM ARTWORK
==================================================

Instead of stock images, create a beautiful live algorithm visualization.

Display:

r e c e i v e

with subtle character alignment.

Then:

r e c i e v e
      ↓
r e c e i v e

Then:

EDIT DISTANCE

01

Use thin mathematical lines.

Behind it, create a very subtle DP grid.

The grid should look almost architectural.

Some cells should illuminate very subtly as the algorithm calculates.

This becomes the visual identity of the product.

Do NOT use:
AI sparkles
brain icons
robot graphics
neural-network illustrations

The mathematics itself should be the visual language.

==================================================
7. LUXURY TRANSITION
==================================================

Below hero, create a large horizontal section.

Left:

01

THE PROBLEM

Large serif text:

"Approximate language
requires approximate matching."

Right:

Explain:

Exact dictionary lookup fails when a query contains typing errors.

LEXICON compares the query against valid dictionary words and measures the minimum edits required to transform one string into another.

Use elegant typography rather than cards.

==================================================
8. CORRECTION ENGINE
==================================================

This should look like a premium research instrument.

Dark interface.

Heading:

CORRECTION ENGINE

Small label:

LOCAL / DETERMINISTIC / DYNAMIC PROGRAMMING

Large input:

recieve

Maximum edit distance:

0    1    2    3

Button:

ANALYZE QUERY

When executed, create a beautiful transformation display.

LEFT:

QUERY

recieve

CENTER:

→

EDIT DISTANCE

01

RIGHT:

BEST MATCH

receive

Then below:

MATCHES WITHIN THRESHOLD

03 CANDIDATES

Results should be elegant and editorial.

Example:

01   receive                 01
02   receiver                02
03   receptive               02

Use thin separators.

No chunky cards.

==================================================
9. RESULT REVEAL ANIMATION
==================================================

When ANALYZE QUERY is pressed:

1. Input remains visible.
2. A thin line sweeps across.
3. DP computation indicator appears.
4. Result count appears.
5. Suggestions reveal sequentially.

Very subtle.

Animation duration:
300–700ms.

Never make it flashy.

It should feel like a high-end instrument processing a request.

==================================================
10. DP MATRIX — MAKE THIS VISUALLY IMPRESSIVE
==================================================

Title:

THE DISTANCE MATRIX

Subtitle:

"Every cell records the minimum transformation cost between two prefixes."

Display the actual DP matrix.

Use a refined dark research-lab interface.

Example:

       r  e  c  e  i  v  e
    ┌────────────────────────
 r  │ 0  1  2  3  4  5  6  7
 e  │ 1  0  1  2  3  4  5  6
 c  │ 2  1  0  1  2  3  4  5
 ...

Use extremely thin borders.

Highlight:
- matching cells
- substitution
- insertion
- deletion
- final distance

The matrix must use the REAL DP algorithm.

Add a small legend beneath it.

MATCH
INSERT
DELETE
SUBSTITUTE

This section should look like a research paper turned into an interface.

==================================================
11. ALGORITHM SECTION
==================================================

Create an immersive vertical storytelling section.

Instead of cards, use large numbered chapters.

01
NORMALIZE

Case-folding
Trimming
Whitespace normalization

02
COMPARE

Query against dictionary vocabulary.

03
CALCULATE

Levenshtein Dynamic Programming.

04
FILTER

Maximum edit-distance threshold.

05
RANK

Ascending edit distance.

Use giant numbers:

01
02
03
04
05

in very large translucent typography.

Create thin connecting lines between stages.

This should look like an architectural diagram.

==================================================
12. DICTIONARY
==================================================

Make the dictionary feel like an archival collection.

Title:

THE DICTIONARY

Subtitle:

"Vocabulary is the boundary of the correction engine."

Show:

WORDS
1,000+

CURATED
ENGLISH

LOCAL
STORAGE

Use actual values where possible.

Create a refined searchable word archive.

Instead of basic cards, display words in elegant columns.

Example:

accept
access
account
accurate
achieve
...

Add:

+ ADD WORD

and:

RESET DICTIONARY

Adding words must actually modify the local dictionary.

Use localStorage.

==================================================
13. REQUIRED ACADEMIC DEMONSTRATIONS
==================================================

Create a section:

CASE STUDIES

Present the required examples beautifully.

CASE 01

recieve

↓

receive

EDIT DISTANCE
01

CANDIDATES
03


CASE 02

wrold

↓

world

EDIT DISTANCE
01

CANDIDATES
02


CASE 03

definately

↓

definitely

EDIT DISTANCE
02

CANDIDATES
04

These values must be preserved exactly.

==================================================
14. EVALUATION
==================================================

Create a premium research-results section.

Title:

EVALUATION

Large editorial statement:

"Accuracy is controlled by distance."

Show the project's findings:

Dictionary:
Common English words

Maximum threshold:
2

Response behavior:
Low response time

Threshold behavior:
Increasing threshold increases recall and candidate processing.

Create an elegant data table.

No fake charts.

No fake performance percentages.

Only use meaningful project information.

==================================================
15. THRESHOLD LAB
==================================================

Create an interactive section:

THRESHOLD LAB

Query:

recieve

Controls:

DISTANCE
0
1
2
3

When threshold changes:

Recalculate results using the real algorithm.

Show:

CANDIDATES
PROCESSING SPACE
MATCHES

Create a simple visual showing the candidate set expanding as the threshold increases.

The visualization must be based on actual results.

==================================================
16. RESEARCH / LITERATURE
==================================================

Make this section resemble a luxury academic journal.

Title:

RESEARCH NOTES

Include:

1960
FREDKIN
Trie

1966
LEVENSHTEIN
Edit Distance

1973
BURKHARD & KELLER
BK-Tree

2007
NORVIG
Probabilistic Spell Correction

2012
GARBE
Symmetric Delete / SymSpell

Create a sophisticated vertical timeline.

Do NOT fabricate information beyond the project's supplied material.

==================================================
17. VIVA MODE
==================================================

Create a premium command-style panel.

Button:

VIVA MODE

When opened:

LEXICON / EXPLAIN

Display concise explanations for:

WHAT IS LEVENSHTEIN DISTANCE?

WHY DYNAMIC PROGRAMMING?

WHAT IS THE RECURRENCE?

WHAT IS THE TIME COMPLEXITY?

WHY USE A THRESHOLD?

WHY RANK BY DISTANCE?

WHAT HAPPENS AS THE DICTIONARY GROWS?

FUTURE SCOPE

Answers should be simple enough to explain confidently in a viva.

==================================================
18. PROJECT CREDITS
==================================================

Create a beautifully designed final section.

DATA STRUCTURES & ALGORITHMS — 03

25CS2103E

SMART SPELL CHECKER

Team:

DHURGA MEENAKSHI YENDURI
2520030270

PRASHANTHI DABBUGUNTA
2520030301

ALAHARI THAPASWI
2520030223

Do NOT invent faculty information.

==================================================
19. FOOTER
==================================================

Very minimal.

LEXICON

Smart Spell Checker

Dictionary-Based Query Correction Using Maximum Edit Distance

25CS2103E

A small line:

BUILT WITH DYNAMIC PROGRAMMING

==================================================
20. MICRO DETAILS THAT MAKE IT LOOK EXPENSIVE
==================================================

Add:

- 1px hairline borders
- tiny uppercase labels
- large whitespace
- asymmetric layouts
- serif/sans typography contrast
- subtle grain
- subtle hover transitions
- sophisticated cursor states where appropriate
- tiny champagne indicators
- elegant section numbering
- thin mathematical grid lines
- editorial page spacing
- carefully aligned baselines
- refined button interactions
- restrained shadows

Avoid excessive rounded corners.

Most major containers should use:
0px–8px radius.

Do not turn everything into a pill.

==================================================
21. RESPONSIVE DESIGN
==================================================

Desktop must be spectacular.

Tablet must preserve the editorial layout.

Mobile must remain elegant rather than becoming a generic stacked dashboard.

The DP matrix can horizontally scroll.

==================================================
22. TECHNICAL IMPLEMENTATION
==================================================

React + TypeScript + Tailwind.

Implement REAL:

levenshteinDistance(query, word)

findSuggestions(query, dictionary, maxDistance)

preprocessQuery(query)

generateDPMatrix(query, word)

Use localStorage for dictionary modifications.

No external AI.

No API calls.

No fake calculations.

No mock results.

==================================================
23. FINAL QUALITY STANDARD
==================================================

Before finishing, inspect the entire application as a professional designer.

Ask:

Does this look expensive?

Does the typography feel intentional?

Does the first screen immediately feel premium?

Does it look custom-built?

Does it look like a serious technology product?

Does the algorithm become part of the visual identity?

Does the faculty immediately understand the project?

Does every animation have a purpose?

Does anything look like a generic AI template?

If ANY section looks like a normal student dashboard, redesign that section.

IMPORTANT:

THE LUXURY VISUAL EXPERIENCE IS NOT OPTIONAL.

Do not sacrifice the premium appearance for a basic functional layout.

The final result should feel like:

"An elite computational language instrument."

Not:

"An AI spell checker website."

Make the application exceptionally polished, rich, cinematic, elegant and premium while remaining academically accurate and easy to explain.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/008d98b6-0ea5-465e-9485-1a9a3495c87e).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
