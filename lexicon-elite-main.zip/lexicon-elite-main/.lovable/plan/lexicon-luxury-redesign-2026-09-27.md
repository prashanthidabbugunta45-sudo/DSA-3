# Lexicon luxury redesign

## Experience
- Replace the placeholder with one cinematic, editorial application at `/`, using the supplied charcoal, ivory, paper, and restrained champagne palette.
- Build a minimal fixed navigation, full-viewport algorithmic hero, asymmetrical editorial sections, and polished mobile/tablet layouts.
- Use a high-contrast serif for the wordmark and display text, paired with a refined sans-serif for controls and technical detail.

## Working features
- Implement query preprocessing, Levenshtein distance, suggestion ranking, and full DP-matrix generation from real calculations.
- Build the correction instrument with threshold controls, sequential result reveal, and a generated matrix for the active query and best match.
- Build a searchable local dictionary that supports adding words and restoring defaults through browser storage.
- Build the threshold lab from live results and a command-style Viva Mode with concise academic explanations.

## Content
- Include the problem statement, five-stage algorithm story, required case studies with their exact displayed values, evaluation findings, research timeline, project credits, and minimal footer.
- Preserve the provided terminology and avoid invented performance claims, faculty details, AI framing, generic dashboards, and decorative card grids.

## Technical details
- Keep the work client-side with React, TypeScript, and Tailwind; no API calls or external AI.
- Define the visual system as semantic theme tokens, add route-specific social metadata, and document the chosen application structure.
- Verify the main correction flow, dictionary persistence, threshold behavior, matrix accuracy, Viva Mode, mobile layout, and final preview health.
