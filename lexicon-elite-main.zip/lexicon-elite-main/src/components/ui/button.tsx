import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { type ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "inline-flex items-center justify-center border text-[10px] font-semibold uppercase tracking-[0.2em] transition-all duration-300 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40",
  {
    variants: {
      variant: {
        outline: "border-champagne/55 bg-transparent text-ivory hover:bg-champagne hover:text-charcoal",
        solid: "border-champagne bg-champagne text-charcoal hover:bg-pale-gold",
        ghost: "border-transparent bg-transparent text-muted-foreground hover:text-ivory",
        default: "border-champagne bg-champagne text-charcoal hover:bg-pale-gold",
        destructive: "border-transparent bg-destructive text-destructive-foreground",
        secondary: "border-transparent bg-secondary text-secondary-foreground",
        link: "h-auto border-transparent bg-transparent p-0 text-foreground underline-offset-4 hover:underline",
      },
      size: {
        default: "h-12 px-6",
        sm: "h-9 px-3",
        lg: "h-14 px-8",
        icon: "h-10 w-10 p-0",
      },
    },
    defaultVariants: { variant: "outline", size: "default" },
  },
);

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof buttonVariants> & {
  asChild?: boolean;
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ asChild, className, variant, size, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      />
    );
  },
);
Button.displayName = "Button";
