import { createFileRoute } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, Menu, Plus, RotateCcw, Search, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { DEFAULT_DICTIONARY, findSuggestions, generateDPMatrix, preprocessQuery } from "@/lib/lexicon";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "LEXICON — Smart Spell Checker" },
    { name: "description", content: "A dictionary-driven correction engine built with Levenshtein distance and dynamic programming." },
    { property: "og:title", content: "LEXICON — Smart Spell Checker" },
    { property: "og:description", content: "An elite computational language instrument for dictionary-based query correction." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Lexicon,
});

const nav = [["CORRECT","engine"],["DICTIONARY","dictionary"],["ALGORITHM","algorithm"],["EVALUATION","evaluation"],["RESEARCH","research"]] as const;
const vivaItems = [
  ["WHAT IS LEVENSHTEIN DISTANCE?", "The minimum number of single-character insertions, deletions, or substitutions needed to transform one string into another."],
  ["WHY DYNAMIC PROGRAMMING?", "The problem contains overlapping prefix comparisons. Dynamic programming stores each result once instead of recalculating it."],
  ["WHAT IS THE RECURRENCE?", "If characters match, copy the diagonal cost. Otherwise take one plus the minimum of insertion, deletion, and substitution."],
  ["WHAT IS THE TIME COMPLEXITY?", "For strings of lengths m and n, one comparison takes O(mn) time and O(mn) space for the displayed matrix."],
  ["WHY USE A THRESHOLD?", "A threshold limits results to words close enough to be useful and reduces the visible candidate set."],
  ["WHY RANK BY DISTANCE?", "Lower edit distance means fewer transformations, so the closest likely correction appears first."],
  ["WHAT HAPPENS AS THE DICTIONARY GROWS?", "More words must be compared, so total work grows linearly with dictionary size for this implementation."],
  ["FUTURE SCOPE", "A trie, BK-tree, frequency ranking, or SymSpell index could improve retrieval speed and ranking at larger scale."],
];

function scrollTo(id: string) { document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }); }

function Lexicon() {
  const [dictionary, setDictionary] = useState<string[]>(DEFAULT_DICTIONARY);
  const [query, setQuery] = useState("recieve");
  const [threshold, setThreshold] = useState(2);
  const [analyzed, setAnalyzed] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [search, setSearch] = useState("");
  const [newWord, setNewWord] = useState("");
  const [vivaOpen, setVivaOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const saved = window.localStorage.getItem("lexicon-dictionary");
    if (saved) { try { const parsed = JSON.parse(saved) as unknown; if (Array.isArray(parsed)) setDictionary(parsed.filter((x): x is string => typeof x === "string")); } catch { /* use defaults */ } }
  }, []);
  const persist = (words: string[]) => { setDictionary(words); window.localStorage.setItem("lexicon-dictionary", JSON.stringify(words)); };
  const suggestions = useMemo(() => findSuggestions(query, dictionary, threshold), [query, dictionary, threshold]);
  const best = suggestions[0]?.word ?? preprocessQuery(query);
  const matrix = useMemo(() => generateDPMatrix(query, best), [query, best]);
  const filteredWords = dictionary.filter((word) => word.includes(preprocessQuery(search))).sort();
  const analyze = () => { setAnalyzed(false); setProcessing(true); window.setTimeout(() => { setProcessing(false); setAnalyzed(true); }, 520); };
  const addWord = () => { const word = preprocessQuery(newWord); if (word && !dictionary.includes(word)) persist([...dictionary, word]); setNewWord(""); };

  return <main className="min-h-screen overflow-x-hidden bg-charcoal text-ivory">
    <header className="fixed inset-x-0 top-0 z-40 border-b border-line bg-charcoal/95 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-[1600px] items-center px-5 lg:px-10">
        <button onClick={() => scrollTo("top")} className="cursor-pointer border-r border-line pr-7 text-left" aria-label="Lexicon home">
          <span className="block font-display text-[22px] leading-none tracking-[0.18em]">LEXICON</span><span className="mt-1.5 block text-[7px] tracking-[0.28em] text-muted-foreground">SMART SPELL CHECKER</span>
        </button>
        <nav className="ml-auto hidden items-center lg:flex">{nav.map(([label,id]) => <button key={id} onClick={() => scrollTo(id)} className="cursor-pointer px-4 text-[9px] tracking-[0.2em] text-muted-foreground transition-colors hover:text-ivory xl:px-6">{label}</button>)}</nav>
        <div className="ml-auto hidden items-center gap-6 border-l border-line pl-7 lg:flex"><span className="flex items-center gap-2 text-[8px] tracking-[0.18em] text-muted-foreground"><i className="h-1.5 w-1.5 rounded-full bg-champagne shadow-[0_0_10px_var(--champagne)]"/>LOCAL ENGINE</span><Button onClick={() => setVivaOpen(true)} className="h-9 px-4">VIVA MODE</Button></div>
        <button aria-label="Open menu" onClick={() => setMobileOpen(!mobileOpen)} className="ml-auto cursor-pointer p-2 lg:hidden">{mobileOpen ? <X size={20}/> : <Menu size={20}/>}</button>
      </div>
      {mobileOpen && <div className="border-t border-line bg-charcoal px-5 py-6 lg:hidden">{nav.map(([label,id]) => <button key={id} onClick={() => {scrollTo(id);setMobileOpen(false)}} className="block w-full border-b border-line py-4 text-left text-[10px] tracking-[0.2em]">{label}</button>)}<Button onClick={() => setVivaOpen(true)} className="mt-5 w-full">VIVA MODE</Button></div>}
    </header>

    <section id="top" className="relative min-h-[100svh] overflow-hidden border-b border-line pt-20">
      <div className="absolute inset-0 algorithm-grid opacity-50"/><div className="relative mx-auto grid min-h-[calc(100svh-5rem)] max-w-[1600px] lg:grid-cols-[1.08fr_.92fr]">
        <div className="flex flex-col justify-between px-5 py-12 lg:border-r lg:border-line lg:px-10 lg:py-16">
          <div className="eyebrow">DATA STRUCTURES &amp; ALGORITHMS — 03</div>
          <div className="my-16"><div className="mb-5 flex items-end gap-4"><h1 className="font-display text-[clamp(4.5rem,12vw,11.5rem)] leading-[.7] tracking-[0.04em]">LEXICON</h1><span className="hidden pb-1 text-[9px] tracking-[.3em] text-champagne md:block">SMART SPELL CHECKER</span></div><h2 className="max-w-4xl font-display text-[clamp(2.5rem,5.7vw,6.5rem)] leading-[.93] text-paper">Precision begins<br/><em className="font-normal text-muted-foreground">with the smallest edit.</em></h2></div>
          <div className="grid items-end gap-8 md:grid-cols-[1fr_auto]"><p className="max-w-xl text-sm leading-7 text-muted-foreground">A dictionary-driven correction engine that transforms imperfect queries into precise words using Levenshtein distance and Dynamic Programming.</p><div className="flex flex-wrap gap-3"><Button onClick={() => scrollTo("engine")} variant="solid">OPEN CORRECTION ENGINE</Button><Button onClick={() => scrollTo("algorithm")}>VIEW THE ALGORITHM</Button></div></div>
        </div>
        <HeroAlgorithm />
      </div>
    </section>

    <section className="bg-paper text-ink"><div className="mx-auto grid max-w-[1600px] px-5 py-24 md:grid-cols-[.4fr_1.25fr_1fr] md:px-10 md:py-36"><div><span className="font-display text-7xl text-gold">01</span><p className="eyebrow mt-5 text-ink-muted">THE PROBLEM</p></div><h2 className="mt-12 max-w-2xl font-display text-5xl leading-[1.02] md:mt-0 md:text-7xl">Approximate language requires approximate matching.</h2><div className="mt-12 border-t border-ink/20 pt-6 text-sm leading-7 text-ink-muted md:ml-12 md:mt-0"><p>Exact dictionary lookup fails when a query contains typing errors.</p><p className="mt-5">LEXICON compares the query against valid dictionary words and measures the minimum edits required to transform one string into another.</p></div></div></section>

    <section id="engine" className="section-dark"><SectionHead number="02" label="CORRECTION ENGINE" title="A precise instrument for imperfect queries." dark />
      <div className="mx-auto max-w-[1600px] border-y border-line px-5 py-10 md:px-10 md:py-14"><div className="mb-10 flex flex-wrap items-center justify-between gap-4"><p className="eyebrow">LOCAL / DETERMINISTIC / DYNAMIC PROGRAMMING</p><span className="text-[9px] tracking-[.18em] text-muted-foreground">{processing ? "COMPUTING MATRIX…" : "SYSTEM READY"}</span></div>
        <div className="grid gap-10 lg:grid-cols-[1fr_auto_auto]"><label><span className="eyebrow mb-4 block">QUERY INPUT</span><input value={query} onChange={(e) => {setQuery(e.target.value);setAnalyzed(false)}} className="w-full border-b border-line bg-transparent pb-3 font-display text-6xl text-ivory outline-none transition-colors focus:border-champagne" aria-label="Query input" /></label><fieldset><legend className="eyebrow mb-4">MAXIMUM EDIT DISTANCE</legend><div className="flex border border-line">{[0,1,2,3].map(n => <button key={n} onClick={() => {setThreshold(n);setAnalyzed(false)}} className={`h-14 w-14 cursor-pointer border-r border-line font-display text-2xl last:border-r-0 ${threshold===n ? "bg-champagne text-charcoal" : "text-muted-foreground hover:text-ivory"}`}>{n}</button>)}</div></fieldset><Button onClick={analyze} variant="solid" className="self-end">ANALYZE QUERY <ArrowRight className="ml-3" size={14}/></Button></div>
        <div className={`relative mt-14 border-t border-line pt-10 transition-opacity duration-500 ${analyzed ? "opacity-100" : "opacity-25"}`}><div className={processing ? "sweep-line" : ""}/><div className="grid items-center gap-8 md:grid-cols-[1fr_auto_1fr_auto_1fr]"><Metric label="QUERY" value={preprocessQuery(query) || "—"}/><ArrowRight className="hidden text-champagne md:block"/><Metric label="EDIT DISTANCE" value={suggestions[0] ? String(suggestions[0].distance).padStart(2,"0") : "—"} gold/><ArrowRight className="hidden text-champagne md:block"/><Metric label="BEST MATCH" value={suggestions[0]?.word ?? "No match"}/></div>
          <div className="mt-14 grid gap-8 lg:grid-cols-[.65fr_1.35fr]"><div><p className="eyebrow">MATCHES WITHIN THRESHOLD</p><p className="mt-4 font-display text-5xl"><span className="text-gold">{String(suggestions.length).padStart(2,"0")}</span> <span className="text-2xl text-muted-foreground">CANDIDATES</span></p></div><div>{suggestions.slice(0,6).map((s,i) => <div key={s.word} style={{animationDelay:`${i*70}ms`}} className="result-row grid grid-cols-[3rem_1fr_auto] border-t border-line py-4 text-sm"><span className="text-gold">{String(i+1).padStart(2,"0")}</span><span>{s.word}</span><span className="font-display text-xl">{String(s.distance).padStart(2,"0")}</span></div>)}{!suggestions.length && <p className="border-t border-line py-6 text-muted-foreground">No candidates fall within this threshold.</p>}</div></div>
        </div>
      </div>
    </section>

    <MatrixSection query={query} target={best} matrix={matrix}/>

    <section id="algorithm" className="bg-paper text-ink"><SectionHead number="04" label="THE METHOD" title="Five stages. One deterministic result." /><div className="mx-auto max-w-[1600px] px-5 pb-28 md:px-10">{[
      ["01","NORMALIZE","Case-folding · Trimming · Whitespace normalization"],["02","COMPARE","Query against dictionary vocabulary."],["03","CALCULATE","Levenshtein Dynamic Programming."],["04","FILTER","Maximum edit-distance threshold."],["05","RANK","Ascending edit distance."]
    ].map(([n,t,d],i)=><div key={n} className="group grid min-h-40 border-t border-ink/20 py-8 md:grid-cols-[.35fr_.65fr_1fr] md:items-center"><span className="font-display text-7xl text-gold/45 transition-colors group-hover:text-gold md:text-8xl">{n}</span><h3 className="mt-4 text-xs tracking-[.25em] md:mt-0">{t}</h3><p className="mt-3 text-sm text-ink-muted md:mt-0">{d}</p>{i<4 && <span className="hidden"/>}</div>)}</div></section>

    <DictionarySection dictionary={dictionary} filteredWords={filteredWords} search={search} setSearch={setSearch} newWord={newWord} setNewWord={setNewWord} addWord={addWord} reset={() => persist(DEFAULT_DICTIONARY)}/>
    <CaseStudies />
    <Evaluation />
    <ThresholdLab dictionary={dictionary}/>
    <Research />
    <Credits />
    <Footer />
    {vivaOpen && <VivaPanel onClose={() => setVivaOpen(false)}/>} 
  </main>;
}

function HeroAlgorithm(){ const source="recieve", target="receive"; return <div className="relative flex min-h-[560px] items-center justify-center overflow-hidden px-5 py-16 lg:min-h-0"><div className="absolute inset-0 matrix-grid"/><div className="relative w-full max-w-lg"><div className="mb-14 flex items-center justify-between"><span className="eyebrow">LIVE COMPARISON</span><span className="h-px w-28 bg-champagne/50"/></div><div className="space-y-8 font-mono text-[clamp(1.3rem,3vw,2.25rem)] tracking-[.35em]"><div className="flex justify-between">{source.split("").map((c,i)=><span key={i} className={i===3?"text-gold":"text-muted-foreground"}>{c}</span>)}</div><div className="flex justify-center"><ArrowDown size={18} className="text-champagne"/></div><div className="flex justify-between">{target.split("").map((c,i)=><span key={i} className={i===3?"text-gold":"text-ivory"}>{c}</span>)}</div></div><div className="mt-16 flex items-end justify-between border-t border-line pt-7"><span className="eyebrow">EDIT DISTANCE</span><span className="font-display text-8xl leading-none text-gold">01</span></div></div></div>}
function SectionHead({number,label,title,dark=false}:{number:string;label:string;title:string;dark?:boolean}){return <div className="mx-auto grid max-w-[1600px] gap-6 px-5 py-20 md:grid-cols-[.4fr_1.6fr] md:px-10 md:py-28"><div><span className="font-display text-6xl text-gold">{number}</span><p className={`eyebrow mt-4 ${dark?"":"text-ink-muted"}`}>{label}</p></div><h2 className="max-w-4xl font-display text-5xl leading-none md:text-7xl">{title}</h2></div>}
function Metric({label,value,gold=false}:{label:string;value:string;gold?:boolean}){return <div><p className="eyebrow mb-4">{label}</p><p className={`font-display text-5xl md:text-6xl ${gold?"text-gold":"text-ivory"}`}>{value}</p></div>}

function MatrixSection({query,target,matrix}:{query:string;target:string;matrix:number[][]}){ const a=preprocessQuery(query), b=preprocessQuery(target); return <section className="section-dark border-t border-line"><SectionHead number="03" label="THE DISTANCE MATRIX" title="Every cell records the minimum transformation cost between two prefixes." dark/><div className="mx-auto max-w-[1600px] px-5 pb-28 md:px-10"><div className="overflow-x-auto border-y border-line py-8"><table className="mx-auto border-collapse font-mono text-xs"><thead><tr><th className="matrix-cell text-muted-foreground">∅</th>{b.split("").map((c,j)=><th className="matrix-cell text-champagne" key={j}>{c}</th>)}</tr></thead><tbody>{matrix.map((row,i)=><tr key={i}><th className="matrix-cell text-champagne">{i===0?"∅":a[i-1]}</th>{row.map((v,j)=>{const match=i>0&&j>0&&a[i-1]===b[j-1];const final=i===matrix.length-1&&j===row.length-1;return <td key={j} className={`matrix-cell ${final?"matrix-final":match?"matrix-match":""}`}>{v}</td>})}</tr>)}</tbody></table></div><div className="mt-7 flex flex-wrap gap-x-8 gap-y-3">{[["MATCH","bg-champagne"],["INSERT","bg-ivory/40"],["DELETE","bg-ivory/40"],["SUBSTITUTE","bg-gold/60"]].map(([x,c])=><span key={x} className="flex items-center gap-2 text-[8px] tracking-[.2em] text-muted-foreground"><i className={`h-1.5 w-1.5 ${c}`}/>{x}</span>)}</div></div></section>}

function DictionarySection(p:{dictionary:string[];filteredWords:string[];search:string;setSearch:(x:string)=>void;newWord:string;setNewWord:(x:string)=>void;addWord:()=>void;reset:()=>void}){return <section id="dictionary" className="bg-ivory text-ink"><SectionHead number="05" label="THE DICTIONARY" title="Vocabulary is the boundary of the correction engine."/><div className="mx-auto max-w-[1600px] px-5 pb-28 md:px-10"><div className="grid border-y border-ink/20 md:grid-cols-3">{[["WORDS",String(p.dictionary.length).padStart(3,"0")],["CURATED","ENGLISH"],["LOCAL","STORAGE"]].map(([a,b])=><div key={a} className="border-b border-ink/20 py-8 md:border-b-0 md:border-r md:px-8 md:first:pl-0 md:last:border-r-0"><p className="eyebrow text-ink-muted">{a}</p><p className="mt-4 font-display text-4xl">{b}</p></div>)}</div><div className="mt-14 grid gap-10 lg:grid-cols-[.45fr_1.55fr]"><div className="space-y-7"><label className="flex items-center border-b border-ink/25 py-3"><Search size={15}/><input value={p.search} onChange={e=>p.setSearch(e.target.value)} placeholder="SEARCH ARCHIVE" className="ml-3 w-full bg-transparent text-xs tracking-[.16em] outline-none placeholder:text-ink-muted"/></label><div className="flex border-b border-ink/25 py-3"><input value={p.newWord} onChange={e=>p.setNewWord(e.target.value)} onKeyDown={e=>{if(e.key==="Enter")p.addWord()}} placeholder="ADD A WORD" className="w-full bg-transparent text-xs tracking-[.16em] outline-none placeholder:text-ink-muted"/><button onClick={p.addWord} aria-label="Add word" className="cursor-pointer"><Plus size={17}/></button></div><Button onClick={p.reset} className="border-ink/40 text-ink hover:bg-ink hover:text-ivory"><RotateCcw size={13} className="mr-3"/>RESET DICTIONARY</Button></div><div className="grid max-h-[430px] grid-cols-2 overflow-y-auto border-t border-ink/20 sm:grid-cols-3 md:grid-cols-4">{p.filteredWords.map((word,i)=><div key={word} className="border-b border-r border-ink/15 px-4 py-4 font-display text-xl"><span className="mr-2 align-top font-sans text-[8px] text-gold">{String(i+1).padStart(2,"0")}</span>{word}</div>)}</div></div></div></section>}

function CaseStudies(){const cases=[["01","recieve","receive","01","03"],["02","wrold","world","01","02"],["03","definately","definitely","02","04"]];return <section className="bg-paper text-ink"><SectionHead number="06" label="CASE STUDIES" title="Correction, observed."/><div className="mx-auto max-w-[1600px] px-5 pb-28 md:px-10">{cases.map(c=><div key={c[0]} className="grid border-t border-ink/20 py-8 md:grid-cols-[.3fr_1fr_auto_1fr_.7fr_.7fr] md:items-center"><span className="eyebrow text-ink-muted">CASE {c[0]}</span><span className="mt-4 font-display text-4xl md:mt-0">{c[1]}</span><ArrowRight className="my-3 text-gold md:my-0"/><span className="font-display text-4xl">{c[2]}</span><span className="mt-5 text-xs md:mt-0">EDIT DISTANCE <b className="ml-2 font-display text-3xl text-gold">{c[3]}</b></span><span className="mt-2 text-xs md:mt-0">CANDIDATES <b className="ml-2 font-display text-3xl">{c[4]}</b></span></div>)}</div></section>}

function Evaluation(){return <section id="evaluation" className="bg-ivory text-ink"><SectionHead number="07" label="EVALUATION" title="Accuracy is controlled by distance."/><div className="mx-auto max-w-[1600px] px-5 pb-28 md:px-10"><div className="grid border-t border-ink/20 md:grid-cols-2">{[["DICTIONARY","Common English words"],["MAXIMUM THRESHOLD","2"],["RESPONSE BEHAVIOR","Low response time"],["THRESHOLD BEHAVIOR","Increasing threshold increases recall and candidate processing."]].map(([a,b])=><div key={a} className="border-b border-ink/20 py-8 md:pr-12 md:odd:border-r md:even:pl-12"><p className="eyebrow text-ink-muted">{a}</p><p className="mt-5 font-display text-3xl">{b}</p></div>)}</div></div></section>}

function ThresholdLab({dictionary}:{dictionary:string[]}){const [t,setT]=useState(1);const results=findSuggestions("recieve",dictionary,t);return <section className="section-dark"><SectionHead number="08" label="THRESHOLD LAB" title="Watch the candidate space expand." dark/><div className="mx-auto grid max-w-[1600px] gap-12 px-5 pb-28 md:px-10 lg:grid-cols-[.7fr_1.3fr]"><div><p className="eyebrow">QUERY</p><p className="mt-4 font-display text-6xl">recieve</p><p className="eyebrow mt-12">DISTANCE</p><div className="mt-4 flex border border-line">{[0,1,2,3].map(n=><button key={n} onClick={()=>setT(n)} className={`h-16 flex-1 cursor-pointer border-r border-line font-display text-2xl last:border-0 ${t===n?"bg-champagne text-charcoal":""}`}>{n}</button>)}</div></div><div><div className="grid grid-cols-3 border-y border-line py-7"><Metric label="CANDIDATES" value={String(results.length).padStart(2,"0")} gold/><Metric label="PROCESSING SPACE" value={String(dictionary.length)}/><Metric label="MATCHES" value={String(results.length)}/></div><div className="mt-10 space-y-3">{[0,1,2,3].map(n=>{const count=findSuggestions("recieve",dictionary,n).length;return <div key={n} className="grid grid-cols-[2rem_1fr_2rem] items-center gap-3"><span className="text-xs text-muted-foreground">{n}</span><div className="h-1 bg-line"><div className="h-full bg-champagne transition-all duration-500" style={{width:`${Math.max(2,Math.min(100,count*12))}%`}}/></div><span className="text-xs">{count}</span></div>})}</div></div></div></section>}

function Research(){const items=[["1960","FREDKIN","Trie"],["1966","LEVENSHTEIN","Edit Distance"],["1973","BURKHARD & KELLER","BK-Tree"],["2007","NORVIG","Probabilistic Spell Correction"],["2012","GARBE","Symmetric Delete / SymSpell"]];return <section id="research" className="bg-paper text-ink"><SectionHead number="09" label="RESEARCH NOTES" title="A brief lineage of approximate matching."/><div className="mx-auto max-w-[1100px] px-5 pb-28 md:px-10">{items.map(([year,name,work])=><div key={year} className="relative grid border-t border-ink/20 py-8 md:grid-cols-[.4fr_1fr_1fr]"><span className="font-display text-5xl text-gold">{year}</span><span className="mt-4 text-xs tracking-[.2em] md:mt-3">{name}</span><span className="mt-2 font-display text-2xl text-ink-muted md:mt-2">{work}</span></div>)}</div></section>}
function Credits(){return <section className="bg-ivory text-ink"><div className="mx-auto grid max-w-[1600px] px-5 py-28 md:grid-cols-[.8fr_1.2fr] md:px-10 md:py-40"><div><p className="eyebrow text-ink-muted">DATA STRUCTURES &amp; ALGORITHMS — 03</p><p className="mt-6 font-display text-7xl">25CS2103E</p><h2 className="mt-8 font-display text-4xl">Smart Spell Checker</h2></div><div className="mt-16 md:mt-0 md:border-l md:border-ink/20 md:pl-16"><p className="eyebrow text-ink-muted">PROJECT TEAM</p>{[["DHURGA MEENAKSHI YENDURI","2520030270"],["PRASHANTHI DABBUGUNTA","2520030301"],["ALAHARI THAPASWI","2520030223"]].map(([n,id])=><div key={id} className="flex flex-col justify-between border-b border-ink/20 py-6 sm:flex-row sm:items-end"><span className="font-display text-2xl">{n}</span><span className="mt-2 text-[10px] tracking-[.2em] text-ink-muted sm:mt-0">{id}</span></div>)}</div></div></section>}
function Footer(){return <footer className="border-t border-line bg-charcoal px-5 py-14 text-ivory md:px-10"><div className="mx-auto flex max-w-[1600px] flex-col justify-between gap-10 md:flex-row md:items-end"><div><p className="font-display text-4xl tracking-[.12em]">LEXICON</p><p className="mt-2 text-[9px] tracking-[.22em] text-muted-foreground">SMART SPELL CHECKER</p></div><div className="text-xs leading-6 text-muted-foreground"><p>Dictionary-Based Query Correction Using Maximum Edit Distance</p><p>25CS2103E</p></div><p className="eyebrow flex items-center gap-3"><i className="h-1 w-1 bg-champagne"/>BUILT WITH DYNAMIC PROGRAMMING</p></div></footer>}
function VivaPanel({onClose}:{onClose:()=>void}){return <div className="fixed inset-0 z-50 bg-charcoal/70 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Viva Mode"><div className="absolute inset-y-0 right-0 w-full max-w-2xl overflow-y-auto border-l border-line bg-secondary p-6 shadow-2xl md:p-12"><div className="mb-12 flex items-start justify-between"><div><p className="eyebrow text-champagne">LEXICON / EXPLAIN</p><h2 className="mt-4 font-display text-5xl">Viva Mode</h2></div><button onClick={onClose} aria-label="Close Viva Mode" className="cursor-pointer border border-line p-3 hover:border-champagne"><X size={18}/></button></div>{vivaItems.map(([q,a],i)=><details key={q} className="group border-t border-line py-6" open={i===0}><summary className="flex cursor-pointer list-none items-center justify-between text-[10px] tracking-[.18em]"><span>{q}</span><Plus size={15} className="transition-transform group-open:rotate-45"/></summary><p className="max-w-xl pt-5 text-sm leading-7 text-muted-foreground">{a}</p></details>)}</div></div>}
