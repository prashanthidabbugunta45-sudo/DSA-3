export type Suggestion = { word: string; distance: number };

export const DEFAULT_DICTIONARY = [
  "accept", "access", "account", "accurate", "achieve", "algorithm", "analysis", "archive", "array", "balance",
  "binary", "calculate", "candidate", "character", "collection", "compare", "complexity", "computer", "correct", "correction",
  "data", "define", "definite", "definitely", "delete", "dictionary", "distance", "dynamic", "edit", "engine",
  "evaluate", "exact", "filter", "function", "graph", "index", "insert", "language", "local", "match",
  "matrix", "memory", "method", "minimum", "normalize", "precision", "prefix", "process", "programming", "query",
  "rank", "receive", "receiver", "receptive", "recieve", "research", "response", "result", "search", "space",
  "spell", "string", "structure", "substitute", "suggestion", "threshold", "transform", "tree", "value", "vocabulary",
  "word", "world", "would", "write", "wrong"
];

export function preprocessQuery(value: string) {
  return value.toLocaleLowerCase().trim().replace(/\s+/g, " ");
}

export function generateDPMatrix(source: string, target: string) {
  const a = preprocessQuery(source);
  const b = preprocessQuery(target);
  const matrix = Array.from({ length: a.length + 1 }, () => Array<number>(b.length + 1).fill(0));
  for (let i = 0; i <= a.length; i += 1) {
    const row = matrix[i];
    if (row) row[0] = i;
  }
  const firstRow = matrix[0];
  if (firstRow) for (let j = 0; j <= b.length; j += 1) firstRow[j] = j;
  for (let i = 1; i <= a.length; i += 1) {
    for (let j = 1; j <= b.length; j += 1) {
      const substitution = a[i - 1] === b[j - 1] ? 0 : 1;
      const row = matrix[i];
      const previousRow = matrix[i - 1];
      if (!row || !previousRow) continue;
      row[j] = Math.min(
        (previousRow[j] ?? 0) + 1,
        (row[j - 1] ?? 0) + 1,
        (previousRow[j - 1] ?? 0) + substitution,
      );
    }
  }
  return matrix;
}

export function levenshteinDistance(query: string, word: string) {
  const matrix = generateDPMatrix(query, word);
  const firstRow = matrix[0];
  const lastRow = matrix[matrix.length - 1];
  if (!firstRow || !lastRow) return 0;
  return lastRow[firstRow.length - 1] ?? 0;
}

export function findSuggestions(query: string, dictionary: string[], maxDistance: number) {
  const normalized = preprocessQuery(query);
  if (!normalized) return [];
  return dictionary
    .filter((word) => preprocessQuery(word) !== normalized)
    .map((word) => ({ word, distance: levenshteinDistance(normalized, word) }))
    .filter(({ distance }) => distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance || a.word.localeCompare(b.word));
}
