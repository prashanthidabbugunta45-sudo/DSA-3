<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep Lexicon as a client-side, single-route computational instrument; this preserves deterministic local processing and the editorial narrative.
- Keep all dictionary correction logic in a framework-independent utility module; this makes academic calculations inspectable and testable.
