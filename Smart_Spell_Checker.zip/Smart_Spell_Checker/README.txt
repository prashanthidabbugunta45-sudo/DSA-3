SMART SPELL CHECKER — DSA-3 PBL PROJECT
========================================

HOW TO RUN IN VS CODE (WINDOWS)
1. Download and extract Smart_Spell_Checker.zip.
2. Open VS Code.
3. Select File > Open Folder and choose the extracted Smart_Spell_Checker folder.
4. Open smart_spell_checker.py.
5. Open Terminal > New Terminal.
6. Run one of these commands:

   python smart_spell_checker.py

   or

   py smart_spell_checker.py

REQUIREMENTS
- Python 3
- No extra Python packages are required.

TRY THESE INPUTS
- recieve
- wrold
- definately
- helo
- type exit to close the program

PROJECT CONCEPTS
- Dictionary / Set
- String preprocessing
- Levenshtein Edit Distance
- Dynamic Programming
- Sorting candidate suggestions

NOTE
This project uses a small demonstration dictionary. Add more words to
DEFAULT_DICTIONARY in smart_spell_checker.py to expand its vocabulary.
