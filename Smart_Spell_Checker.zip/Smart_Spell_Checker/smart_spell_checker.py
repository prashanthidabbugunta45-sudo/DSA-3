DEFAULT_DICTIONARY = {
    "a", "about", "above", "accept", "across", "algorithm",
    "apple", "application", "book", "computer", "correction",
    "data", "dictionary", "distance", "document", "dynamic",
    "engine", "example", "hello", "information", "insert",
    "kitten", "language", "maximum", "message", "minimum",
    "mobile", "model", "orange", "program", "python", "query",
    "receive", "search", "spell", "spelling", "system", "text",
    "the", "their", "there", "world", "word", "writing",
    "definitely", "beautiful", "science", "student", "college",
    "education", "technology", "project", "friend", "computer"
}


def levenshtein_distance(source, target):
    """Calculate minimum insertions, deletions and substitutions."""
    source = source.lower()
    target = target.lower()

    n = len(source)
    m = len(target)
    dp = [[0] * (m + 1) for _ in range(n + 1)]

    for i in range(n + 1):
        dp[i][0] = i
    for j in range(m + 1):
        dp[0][j] = j

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = 0 if source[i - 1] == target[j - 1] else 1
            dp[i][j] = min(
                dp[i - 1][j] + 1,       # Deletion
                dp[i][j - 1] + 1,       # Insertion
                dp[i - 1][j - 1] + cost # Match or substitution
            )

    return dp[n][m]


def suggest_corrections(query, dictionary, max_distance=2):
    """Return close dictionary words, nearest first."""
    query = query.strip().lower()
    if not query:
        return []

    candidates = []
    for word in dictionary:
        distance = levenshtein_distance(query, word)
        if distance <= max_distance:
            candidates.append((word, distance))

    candidates.sort(key=lambda item: (item[1], item[0]))
    return candidates


def main():
    dictionary = set(DEFAULT_DICTIONARY)

    print("=" * 48)
    print("             SMART SPELL CHECKER")
    print(" Dictionary-Based Query Correction System")
    print("=" * 48)
    print(f"Dictionary words loaded: {len(dictionary)}")

    while True:
        query = input("\\nEnter a word (or type 'exit' to quit): ").strip()

        if query.lower() == "exit":
            print("Thank you for using Smart Spell Checker!")
            break

        if not query:
            print("Please enter a word.")
            continue

        try:
            max_distance = int(input("Maximum edit distance (1 or 2): "))
            if max_distance < 0:
                print("Distance cannot be negative.")
                continue
        except ValueError:
            print("Invalid distance. Using 2.")
            max_distance = 2

        if query.lower() in dictionary:
            print("\\nThe word is spelled correctly!")
        else:
            print("\\nWord not found. Searching for suggestions...")

        suggestions = suggest_corrections(query, dictionary, max_distance)

        if suggestions:
            print("\\nSuggested corrections:")
            for index, (word, distance) in enumerate(suggestions, start=1):
                print(f"{index}. {word} (Edit Distance: {distance})")
        else:
            print("\\nNo suggestions found within the selected distance.")

        print("-" * 48)


if __name__ == "__main__":
    main()
